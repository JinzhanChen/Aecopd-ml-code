############################### 版本信息查看部分 ####################################

# 查看R库的搜索路径，可了解当前环境下R查找包的位置
.libPaths()

# 查看当前工作目录，即R脚本运行时所在的文件夹路径
getwd()

# 列出当前工作目录下的所有文件（未指定特定模式，会列出所有文件类型）
list.files(path = getwd())

# 查看当前R会话的详细信息，包括已加载的包、R版本等内容
sessionInfo()

############################### 安装所需包 ######################################

# 检查是否已安装dplyr和purrr包，如果未安装则进行安装
if (!require(dplyr)) {
  install.packages("dplyr")
}

if (!require(purrr)) {
  install.packages("purrr")
}

############################## 读取及合并1 ########################################

# 加载dplyr和purrr包，以便后续使用它们提供的函数
library(dplyr)
library(purrr)

# 指定要读取.csv文件的路径
path <- 'E:/ML_aecopd_prolonged/before_merge'

# 列出指定路径下所有符合*.csv模式的文件，并返回完整路径
csv_files <- list.files(path = path, pattern = "*.csv", full.names = TRUE)

# 读取所有.csv文件并存储在一个列表中，以去掉.csv扩展名后的文件名为列表元素名称
# 1. 首先处理文件名，去掉.csv扩展名作为列表元素名称
data_list <- csv_files %>%
  set_names(gsub(".csv$", "", basename(.))) %>%
# 2. 然后使用map函数对每个文件路径应用read.csv函数进行读取，将读取的数据存储在列表中
  map(read.csv)

# 从列表中的第一个数据框开始，依次与后续的数据框进行左连接，合并所有数据
merged_data <- reduce(data_list, left_join, by = c("subject_id"))

# 查看合并后数据框的列名
names(merged_data)

# 选择特定列，去掉'subject_id'、'los_hospital'、"bb"、"hospital_expire_flag"列
data <- dplyr::select(merged_data, -c("subject_id", 'los_hospital', "bb", "hospital_expire_flag"))

# 将'prolonged_hospital_stay'列移到最前面，其余列按原顺序排列
data <- dplyr::select(data, "prolonged_hospital_stay", c(), everything())

# 保存并查看处理后的数据
names(data)
skimr::skim(data)
data.table::fwrite(data, 'merged_data_to_curation.csv')

##################################### 数据处理流程 ###############################

# 参考文章：DOI: 10.1016/j.ebiom.2024.105257

# 读取之前保存的合并后的数据文件
merged_data <- read.csv('merged_data_to_curation.csv')

# 查看列名
names(merged_data)

# 对读取的数据进行简单查看，包括数据结构、缺失值等信息
skimr::skim(merged_data)

# 选取感兴趣的列（此处代码被注释掉，未实际执行选取操作，可根据需求取消注释并修改）
# merged_data <- merged_data[, c(11:ncol(merged_data))]

# 查看数据结构
str(merged_data)

# 去掉缺失关键变量'prolonged_hospital_stay'数据的行
merged_data <- merged_data %>%
  filter(!is.na(prolonged_hospital_stay))

# 再次查看数据结构
str(merged_data)

# 查看列名
colnames(merged_data)

# 查看变量'prolonged_hospital_stay'的取值分布情况
table(merged_data$prolonged_hospital_stay)

############################### 分别处理分类变量，连续变量 #######################

# 分类变量处理

# 定义需要转换为因子类型的列
category_variables <- c(
  "prolonged_hospital_stay",
  "gender",
  "myocardial_infarct", "congestive_heart_failure", "renal_disease", "liver_disease", "diabetes",
  "antibiotic_hosp", "invasivevent_hosp", "vassopressin_hosp"
)

# 使用mutate_at函数将指定的分类变量列转换为因子类型
merged_data <- merged_data %>%
  mutate_at(category_variables, as.factor)

# 连续变量处理

# 获取数据框的所有列名
all_columns <- names(merged_data)

# 通过反选分类变量列来确定连续变量列
continuous_variables <- all_columns[!all_columns %in% category_variables]

############################### 缺失值处理1 #######################################

# 计算每列的缺失值比例
missing_ratio <- map_dbl(merged_data, ~ mean(is.na(.x)))

# 过滤掉缺失值比例超过30%的列（常见阈值20% - 40%）
merged_data <- merged_data %>%
  dplyr::select(names(.)[map_lgl(missing_ratio, ~.x <= 0.3)])

################################ 异常值处理方法1，删失 ###########################

# 确定要处理的连续变量列（这里可确保前面已经正确获取到连续变量列，若已确定可省略此步）
continuous_variables <- continuous_variables

# 计算每个连续变量列的0.0025和0.9975分位数，用于定义异常值范围
outlier_quantiles <- lapply(continuous_variables, function(col) {
  list(lower_quantile = quantile(merged_data[[col]], 0.0025, na.rm = TRUE),
       upper_quantile = quantile(merged_data[[col]], 0.9975, na.rm = TRUE))
})

# 为每个连续变量列的分位数结果设置列名
names(outlier_quantiles) <- continuous_variables

# 定义处理异常值的函数，将小于下限分位数或大于上限分位数的异常值设为缺失值
handle_outliers_as_missing <- function(column_data, quantile_info) {
  column_data[column_data < quantile_info[["lower_quantile"]]] <- NA
  column_data[column_data > quantile_info[["upper_quantile"]]] <- NA
  return(column_data)
}

# 使用dplyr的mutate函数结合across函数对连续变量列中的异常值进行处理
merged_data <- merged_data %>%
  mutate(across(all_of(continuous_variables), function(column) {
    quantiles <- outlier_quantiles[[cur_column()]]
    handle_outliers_as_missing(column, quantiles)
  }))

################################ 异常值处理方法2，盖帽 #########################

# 确定要处理的连续变量列，通过反选分类变量列获取
category_variables  <- c(
  "prolonged_hospital_stay",
  "gender",
  "myocardial_infarct", "congestive_heart_failure", "renal_disease", "liver_disease", "diabetes",
  "antibiotic_hosp", "invasivevent_hosp", "vassopressin_hosp"
)

all_columns <- names(merged_data)

continuous_variables <- all_columns[!all_columns %in% category_variables]

# 计算每个连续变量列的0.0025和0.9975分位数，用于定义异常值范围
outlier_quantiles <- lapply(continuous_variables, function(col) {
  list(lower_quantile = quantile(merged_data[[col]], 0.0025, na.rm = TRUE),
       upper_quantile = quantile(merged_data[[col]], 0.9975, na.rm = TRUE))
})

# 为每个连续变量列的分位数结果设置列名
names(outlier_quantiles) <- continuous_variables

# 定义盖帽法处理异常值的函数，将小于下限分位数或大于上限分位数的异常值赋值为边界值
handle_outliers_winsorize <- function(column_data, quantile_info) {
  column_data[column_data < quantile_info[["lower_quantile"]]] <- quantile_info[["lower_quantile"]]
  column_data[column_data > quantile_info[["upper_quantile"]]] <- quantile_info[["upper_quantile"]]
  return(column_data)
}

# 使用dplyr的mutate函数结合across函数对连续变量列中的异常值进行处理
merged_data <- merged_data %>%
  mutate(across(all_of(continuous_variables), function(column) {
    quantiles := outlier_quantiles[[cur_column()]]
    handle_outliers_winsorize(column, quantiles)
  }))

# 保存用于插补的数据
data.table::fwrite(merged_data, 'curated_data_to_impute_d.csv')

################################## 缺失值处理—多重插补 ###########################

# 使用missRanger包的随机森林（RF）方法估算缺失值等于或小于40%的其余特征（missRanger为快速版）
# 原文使用python版，这里是R语言实现
library(missRanger)

# 设置随机种子，保证结果可复现
set.seed(12345678)

# 进行多重插补操作
imputed_data := missRanger(merged_data, pmm.k = 5, num.trees = 100)

# 对插补后的数据进行简单查看
skimr::skim(imputed_data)

# 保存填补后的数据集
data.table::fwrite(imputed_data, 'imputed_data_to_preprocess_d.csv')

# 原始数据密度曲线绘制（以'ptt_max'列数据为例）
ggplot(merged_data, aes(x = ptt_max)) +
  geom_density(fill = "#377EB8", alpha = 0.7) +
  ggtitle("Original Data Density Curve")

# 插补后数据密度曲线绘制（以'ptt_max'列数据为例）
ggplot(imputed_data, aes(x = ptt_max)) +
  geom_density(fill = "#E41A1C", alpha = 0.7) +
  ggtitle("Imputed Data Density Curve")

################################## 多重插补后处理 ################################

# 载入插补后的数据文件
data := read.csv('imputed_data_to_preprocess_d.csv')

# 对数据进行简单查看
skimr::skim(data)
str(data)

# 定义需要转换为因子类型的列
category_variables := c(
  "prolonged_hospital_stay",
  "gender",
  "myocardial_infarct", "congestive_heart_failure", "renal_disease", "liver_disease", "diabetes",
  "antibiotic_hosp", "invasivevent_hosp", "vassopressin_hosp"
)

# 使用mutate_at函数将指定的列转换为因子类型
data := data %>%
  mutate_at(category_variables, as.factor)

str(data)

# 保存处理后的数据
data.table::fwrite(data, 'preprocessed_data_to_learn_d.csv')

# 查看变量'prolonged_hospital_stay'的取值分布情况
table(data$prolonged_hospital_stay)