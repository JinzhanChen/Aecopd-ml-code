setwd('/Users/city/Library/Mobile Documents/com~apple~CloudDocs/Documents/TJZG/TJZG-全/2025.01.18-250105/分析')
list.files()
# 
load("env.RData" )
# train<-read.csv("splited_train_data_to_train_d.csv")
# test<-read.csv("splited_test_data_to_test_d.csv")



#导包====
library(glmnet)
library(Boruta)
library(caret)
library(MASS)
library(rms)
library(gtsummary)
# install.packages("regplot")
library(regplot)
library(randomForest)
library(mlr)
library(pROC)
library(nnet)
library(e1071)
library(gbm)
library(psych)
library(kknn)


#类型转换/数据集分割====
data[,c(4:9,24:26,39:41)]<-lapply(data[,c(4:9,24:26,39:41)],as.factor)
data[,c(3,10:23,27:38)]<-lapply(data[,c(3,10:23,27:38)],as.numeric)
set.seed(123)
imp<-mice::mice(data[,-1:-2])
data[,-1:-2]<-mice::complete(imp)

data$age<-factor(ifelse(data$age<65,0,1))
summary(data$age)
set.seed(1234)
index<-createDataPartition(data$prolonged_hospital_stay,p=0.8,list = F)
train<-data[index,]
test<-data[-index,]
write.csv(train,"train.csv")
write.csv(test,"test.csv")
#基线表====
tbl_summary(data = data,
            include = colnames(data)[2:41],
            by = 'prolonged_hospital_stay',
            statistic = list(all_continuous() ~ "{median} [{p25}, {p75}]", 
                             all_categorical() ~ "{n} ({p}%)"),)%>%
  add_overall()%>%
  add_p()%>%
  add_significance_stars()

#
tbl_summary(data = data,
            include = colnames(data)[2:41],
            by = 'prolonged_hospital_stay',
            statistic = list(all_continuous() ~ "{median} [{p25}, {p75}]", 
                             all_categorical() ~ "{n} ({p}%)"),)%>%
  add_overall()%>%
  add_p()%>%
  add_significance_stars()

train$index<-0
test$index<-1
data_<-rbind(train,test)

tbl_summary(data = data_,
            include = colnames(data_)[2:42],
            by = 'index',
            statistic = list(all_continuous() ~ "{median} [{p25}, {p75}]", 
                             all_categorical() ~ "{n} ({p}%)"),)%>%
  add_overall()%>%
  add_p()%>%
  add_significance_stars()

?tbl_summary
#1.特征选择====

##lasso====
f <- glmnet(train[,-1:-2],train$prolonged_hospital_stay, 
            family="binomial", alpha=1)#alpha=1:lasso  alpha=0 岭回归

#交叉验证
set.seed(1234)
cv<-cv.glmnet(makeX(train[,-1:-2]),train$prolonged_hospital_stay,
              family="binomial",alpha=1)
final_model <- glmnet(train[,-1:-2], train$prolonged_hospital_stay, 
                      alpha = 1, lambda = cv$lambda.1se)

lasso_features <- rownames(coef(final_model))[coef(final_model)[,1]!=0][-1]

coef(final_model)


d_coef<-data.frame('var' = rownames(coef(final_model)),
                   'coef' = coef(final_model)[,1])

write.csv(d_coef,'/Users/city/Library/Mobile Documents/com~apple~CloudDocs/Documents/TJZG/TJZG-全/2025.01.18-24091453/分析/d_coef.csv')
##Boruta====
boruta_result <- Boruta(train[,lasso_features],
                        train$prolonged_hospital_stay,
                        pValue = 0.01,
                        doTrace=2,
                        maxRuns = 50)
# "confirmed","tentative","unimportant"
var_selected <- getSelectedAttributes(
  boruta_result,withTentative=F)
# int<-intersect(lasso_features,var_selected)
##逐步逻辑回归====
fml<-as.formula(paste0("prolonged_hospital_stay~",
                       paste0(var_selected,collapse = "+")))
log<-glm(fml,
         family = binomial(link = "logit"),
         data = train)
stlog<-stepAIC(log,direction = "both")
sumlog<-summary(stlog);sumlog

lrm(prolonged_hospital_stay ~ hemoglobin_min + platelets_min + 
      aniongap_max + bun_max + potassium_min + chloride_min + antibiotic_hosp + 
      invasivevent_hosp + vassopressin_hosp + sofa + temperature_max + 
      heart_rate_max + aki + sepsis3,
    data = train)
log<-glm(prolonged_hospital_stay ~ hemoglobin_min + platelets_min + 
           aniongap_max + bun_max + potassium_min + chloride_min + antibiotic_hosp + 
           invasivevent_hosp + vassopressin_hosp + sofa + temperature_max + 
           heart_rate_max + aki + sepsis3, 
         data = train,
         family = binomial())

tbl_regression(log,
               exponentiate = T,
               estimate_fun = label_style_number(digits = 3),
               pvalue_fun = label_style_pvalue(digits = 3))

var<-c("hemoglobin_min","platelets_min","aniongap_max","bun_max","potassium_min",
       "chloride_min","antibiotic_hosp","invasivevent_hosp","vassopressin_hosp",
       'sofa',"temperature_max","heart_rate_max","aki","sepsis3")

trainx<-train[,c("prolonged_hospital_stay",var)]
testx<-test[,c("prolonged_hospital_stay",var)]


par(mfrow = c(1,3 ))
plot(f,xvar="lambda", label=TRUE)
plot(cv)
plot(boruta_result)

#2.逻辑回归====
regplot(log, plots=c("density","boxes"),
        observation=FALSE,points=TRUE,
        dencol="lightsteelblue2",boxcol="lightpink",
        col = 'black')
##初步看结果====
pre_log1 <- predict(log,trainx)
roc_log1<-roc(train$prolonged_hospital_stay, 
              pre_log1,ci = T);roc_log1
pre_log2 <- predict(log,testx)
roc_log2<-roc(test$prolonged_hospital_stay, 
              pre_log2,ci = T);roc_log2
#3.随机森林====
##参数选择====

rf.learner <- makeLearner("classif.randomForest", 
                          predict.type = "response")
rf.params <- makeParamSet(
  makeIntegerParam("ntree", lower = 50, upper = 1000),
  makeIntegerParam("mtry", lower = 1, upper = 14),
  makeIntegerParam("maxnodes", lower = 10, upper = 100),
  makeIntegerParam("nodesize", lower = 1, upper = 10)
)

#
trainx<-train[,c("prolonged_hospital_stay",var)]
testx<-test[,c("prolonged_hospital_stay",var)]
#
task.rf <- makeClassifTask(data = trainx, 
                           target = "prolonged_hospital_stay")
class(trainx$prolonged_hospital_stay)

set.seed(123)#保持结果一致
rf.tuned <- tuneParams(rf.learner, task.rf, 
                       resampling = makeResampleDesc("CV", iters = 5), 
                       par.set = rf.params,
                       control = makeTuneControlRandom(maxit = 500), 
                       show.info = TRUE)   
set.seed(1234)
rf <- randomForest(prolonged_hospital_stay ~ ., 
                   data=trainx, 
                   ntree=rf.tuned$x$ntree,
                   mtry=rf.tuned$x$mtry,
                   maxnodes=rf.tuned$x$maxnodes,
                   nodesize=rf.tuned$x$nodesize,
                   type = "classification")
# Result: ntree=985; mtry=6; maxnodes=79; nodesize=4 : 

##初步看结果====
pre_rf1 <- predict(rf,trainx)
roc_rf1<-roc(train$prolonged_hospital_stay, 
             pre_rf1,ci = T);roc_rf1
pre_rf2 <- predict(rf,testx)
roc_rf2<-roc(test$prolonged_hospital_stay, 
             pre_rf2,ci = T);roc_rf2

#4.神经网络====
##参数选择====
param <- makeParamSet(
  makeIntegerParam("size", lower = 2, upper = 30),
  makeIntegerParam("decay", lower = 0, upper = 1),
  makeIntegerParam("maxit", lower = 50, upper = 1000))
nn <- makeLearner("classif.nnet", predict.type = "prob")
#
task.net <- makeClassifTask(data = trainx, target = "prolonged_hospital_stay")
#
set.seed(12345)
nn.tuned <- tuneParams(nn,task.net,
                       resampling = makeResampleDesc("CV", iters = 5),
                       measure = acc, 
                       par.set = param, 
                       control = makeTuneControlRandom(maxit = 500))
#
set.seed(1234)
net <- nnet(
  prolonged_hospital_stay ~ ., 
  data = trainx, 
  size = nn.tuned$x$size, 
  decay = nn.tuned$x$decay,
  linout = F,
  maxit=nn.tuned$x$maxit,
  entropy = T)

net$n #12 28  1
##初步看结果====
pre_net1 <- predict(net,trainx)
roc_net1<-roc(train$prolonged_hospital_stay, 
              pre_net1,ci = T);roc_net1
pre_net2 <- predict(net,testx)
roc_net2<-roc(test$prolonged_hospital_stay, 
              pre_net2,ci = T);roc_net2
#5.SVM====
##参数选择====
svm.learner <- makeLearner("classif.svm", predict.type = "prob")
svm.param <- makeParamSet(
  makeNumericParam("cost", lower = 1, upper = 100),
  makeNumericParam("gamma", lower = 0.001, upper = 1),
  makeIntegerParam("degree", lower = 1, upper = 5),
  makeDiscreteParam("kernel", values = c("radial")))

#
set.seed(123)
task.svm <- makeClassifTask(data = trainx, 
                            target = "prolonged_hospital_stay")
svm.tune <- tuneParams(svm.learner, task.svm, 
                       resampling = makeResampleDesc("CV", iters = 5), 
                       measures = list(mmce), 
                       par.set = svm.param, 
                       control = makeTuneControlRandom(maxit = 500))
fml<-as.formula(paste0("prolonged_hospital_stay ~",
                       paste0(var,collapse = "+")))
svm <- svm(prolonged_hospital_stay ~ hemoglobin_min + platelets_min + aniongap_max + 
             bun_max + potassium_min + chloride_min + antibiotic_hosp + 
             invasivevent_hosp + vassopressin_hosp + sofa + temperature_max + 
             heart_rate_max + aki + sepsis3, 
           data = trainx, 
           kernel ="radial", 
           cost = svm.tune$x$cost, 
           gamma = svm.tune$x$gamma,
           degree = svm.tune$x$degree)
##初步看结果====
pre_svm1 <- predict(svm,trainx)
roc_svm1<-roc(train$prolonged_hospital_stay, 
              pre_svm1,ci = T);roc_svm1
pre_svm2 <- predict(svm,testx)
roc_svm2<-roc(test$prolonged_hospital_stay, 
              pre_svm2,ci = T);roc_svm2

#GBM====
gbm.learner <- makeLearner("classif.gbm", predict.type = "prob")
gbm.param <- makeParamSet(
  makeDiscreteParam("n.trees", values = c(50, 100, 150,200,250)),
  makeDiscreteParam("interaction.depth", values = c(1, 3, 5,7,9)),
  makeDiscreteParam("shrinkage", values = c(0.01, 0.1, 0.3)))
#
set.seed(123)
task.gbm <- makeClassifTask(data = trainx, 
                            target = "prolonged_hospital_stay")
gbm.tune <- tuneParams(gbm.learner, task.gbm, 
                       resampling = makeResampleDesc("CV", iters = 5), 
                       measures = list(mmce), 
                       par.set = gbm.param, 
                       control = makeTuneControlRandom(maxit = 500))
#
gbm <- gbm(
  formula = prolonged_hospital_stay ~ .,
  distribution = "bernoulli",  # 二分类问题使用伯努利分布
  data = trainx,
  n.trees = gbm.tune$x$n.trees,  # 树的数量
  interaction.depth = gbm.tune$x$interaction.depth,  # 树的深度
  shrinkage = gbm.tune$x$shrinkage,  # 学习率
  cv.folds = 5
)

##初步看结果====
pre_gbm1 <- predict(gbm,trainx)
roc_gbm1<-roc(train$prolonged_hospital_stay, 
              pre_gbm1,ci = T);roc_gbm1
pre_gbm2 <- predict(gbm,testx)
roc_gbm2<-roc(test$prolonged_hospital_stay, 
              pre_gbm2,ci = T);roc_gbm2
#Naive Bayes====
nb.learner <- makeLearner("classif.naiveBayes", predict.type = "prob")
nb.param <- makeParamSet(
  makeNumericParam("laplace", lower = 0, upper = 10))
#
set.seed(123)
task.nb <- makeClassifTask(data = trainx, target = "prolonged_hospital_stay")
nb.tune <- tuneParams(nb.learner, task.nb, 
                      resampling = makeResampleDesc("CV", iters = 5), 
                      measures = list(mmce), 
                      par.set = nb.param, 
                      control = makeTuneControlRandom(maxit = 500))
nb  <- naiveBayes(prolonged_hospital_stay ~ ., 
                  data = trainx,
                  laplace = nb.tune$x$laplace)
##初步看结果====
pre_nb1 <- predict(nb,trainx,type = "raw")[,2]
roc_nb1<-roc(trainx$prolonged_hospital_stay, 
             pre_nb1,ci = T);roc_nb1
pre_nb2 <- predict(nb,testx,type = "raw")[,2]
roc_nb2<-roc(test$prolonged_hospital_stay, 
             pre_nb2,ci = T);roc_nb2
#KNN模型====
knn.learner <- makeLearner("classif.kknn", predict.type = "prob")
knn.param <- makeParamSet(
  makeIntegerParam("k", lower = 3, upper = 10))
#
set.seed(123)
task.knn <- makeClassifTask(data = trainx, 
                            target = "prolonged_hospital_stay")
knn.tune <- tuneParams(knn.learner, task.knn, 
                       resampling = makeResampleDesc("CV", iters = 5), 
                       measures = list(mmce), 
                       par.set = knn.param, 
                       control = makeTuneControlRandom(maxit = 500))
knn <- train.kknn(prolonged_hospital_stay ~ ., 
                  data = trainx, 
                  kmax = knn.tune$x$k, 
                  kernel = "rectangular")
##初步看结果====
pre_knn1 <- predict(knn,trainx)
roc_knn1<-roc(trainx$prolonged_hospital_stay, 
              pre_knn1,ci = T);roc_knn1
pre_knn2 <- predict(knn,testx)
roc_knn2<-roc(test$prolonged_hospital_stay, 
              pre_knn2,ci = T);roc_knn2
save.image('/Users/city/Library/Mobile Documents/com~apple~CloudDocs/Documents/TJZG/TJZG-全/2025.01.18-250105/分析/env.RData')



#