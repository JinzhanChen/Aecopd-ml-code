# Table 1 Patients characteristics

################################### 分割数据集获取训练数据 #######################

# 读取经过预处理的数据文件，准备进行数据集分割操作
data <- read.csv('preprocessed_data_to_learn_d.csv')

# 设置随机种子，保证数据分割结果可复现
set.seed(12345678)

# 加载rsample和dplyr包，用于后续的数据分割和处理操作
require(rsample)
require(dplyr)

# 进行分层随机分割数据，将数据按照'prolonged_hospital_stay'变量进行分层
# 其中80%的数据作为训练集，20%的数据作为测试集
split_pbp <- rsample::initial_split(data, 0.8, strata = prolonged_hospital_stay)

# 获取训练集数据
train_data <- rsample::training(split_pbp)

# 获取测试集数据
test_data <- rsample::testing(split_pbp)

# 查看训练集和测试集中'prolonged_hospital_stay'变量的取值分布情况
table(train_data$prolonged_hospital_stay)
table(test_data$prolonged_hospital_stay)

# 保存分割后的训练集和测试集数据到相应文件
data.table::fwrite(train_data,'splited_train_data_to_train_d.csv')
data.table::fwrite(test_data,'splited_test_data_to_test_d.csv')

###################### 合并数据集用于基线表，引入分组变量group ###################

# 再次读取经过预处理的数据文件，用于后续的合并等操作
data <- read.csv("preprocessed_data_to_learn_d.csv")

# 读取之前分割好的训练集数据
train_set <- read.csv('splited_train_data_to_train_d.csv')

# 读取之前分割好的测试集数据
valid_set <- read.csv('splited_test_data_to_test_d.csv')

# 检查训练集和测试集中'prolonged_hospital_stay'变量的取值分布情况，确认分割结果是否符合预期
table(train_set$prolonged_hospital_stay)
table(valid_set$prolonged_hospital_stay)

# 将训练集数据添加一个分组标识'group'，值为'train'
train_set$group <- "train"

# 将测试集数据添加一个分组标识'group'，值为'valid'
valid_set$group <- "valid"

# 将训练集和测试集按行合并成一个新的数据框'baseline'
baseline <- rbind(train_set, valid_set)

# 将'group'列转换为因子类型，以便后续分析处理
baseline$group <- as.factor(baseline$group)

# 检查'group'列是否成功转换为因子类型
is.factor(baseline$group)

# 将合并后的数据框'baseline'赋值给'data'，方便后续统一处理
data <- baseline

# 获取数据框的列名
colnames(data)

# 将数据框转换为标准的数据框格式（确保数据类型等符合要求）
data <- as.data.frame(data)

# # 定义需要批量转换为因子变量的列名向量
# factorCols <- c("gender", "m28d", "group")
# 
# # 循环遍历指定列名向量，将每列的数据类型转换为因子类型
# for (i in factorCols) {
#   data[, i] <- as.factor(data[, i])
# }

# 定义需要转换为因子类型的列名向量，包含变量如下
factorCols <- c(
  "prolonged_hospital_stay",
  "gender",
  "myocardial_infarct", "congestive_heart_failure",
  "renal_disease", "liver_disease", "diabetes",
  "antibiotic_hosp", "invasivevent_hosp", "vassopressin_hosp"
)

# 使用mutate_at函数将指定列转换为因子类型
data <- data %>%
  mutate_at(factorCols, as.factor)

# 对处理后的数据进行简单查看，包括数据结构、缺失值等信息
skimr::skim(data)

################################### 基线表 #######################################

# 将数据框'data'赋值给'baseline'，方便后续以'baseline'指代该数据框进行操作
baseline <- data

# 正态性检验（总样本数 < 5000情况）

# 加载stats包，用于进行Shapiro-Wilk正态性检验
library(stats)

# 创建一个空的数据框，用于存储正态性检验的结果，包括变量名和p值
shapiro_results <- data.frame(variable = character(), pvalue = numeric())

# 循环遍历数据框的每一列
for (i in 1:ncol(baseline)) {
  
  # 如果该列是数值型数据
  if (is.numeric(baseline[, i])) {
    
    # 对该列进行Shapiro-Wilk正态性检验
    shapiro_test <- shapiro.test(baseline[, i])
    
    # 将检验结果（变量名和p值）添加到结果数据框中
    shapiro_results <- rbind(shapiro_results,
                             data.frame(variable = colnames(baseline)[i],
                                        pvalue = shapiro_test$p.value))
    
  } else {
    
    # 如果该列不是数值型数据，打印提示信息说明是分类变量
    print(paste0(colnames(baseline[i]), " 是分类变量"))
    
  }
}

# 根据p值判断该变量是否符合正态分布，并添加相应列到结果数据框中
shapiro_results$normalitytest <- ifelse(shapiro_results$pvalue > 0.05, "正态分布", "不符合正态分布")

# 查看正态性检验结果（可在RStudio中通过View函数查看数据框内容）
View(shapiro_results)

# 也可以使用print语句输出结果，如下：
# print(shapiro_results)

# 正态性检验（总样本数 > 5000情况）

# 加载nortest包，用于进行Kolmogorov-Smirnov正态性检验
library(nortest)

# 重新创建一个空的数据框，用于存储正态性检验的结果，包括变量名和p值
shapiro_results <- data.frame(variable = character(), pvalue = numeric())

# 循环遍历数据框的每一列
for (i in 1:ncol(baseline)) {
  
  # 如果该列是数值型数据
  if (is.numeric(baseline[, i]) && is.numeric(baseline[, i])) {
    
    # 对该列进行Kolmogorov-Smirnov正态性检验，传入均值和标准差参数
    ks_test := ks.test(baseline[, i], "pnorm", mean = mean(baseline[, i]), sd = sd(baseline[, i]))
    
    # 将检验结果（变量名和p值）添加到结果数据框中
    shapiro_results := rbind(shapiro_results,
                             data.frame(variable = colnames(baseline)[i],
                                        pvalue = ks_test$p.value))
    
  } else {
    
    # 如果该列不是数值型数据，打印提示信息说明是分类变量
    print(paste0(colnames(baseline[i]), " 是分类变量"))
    
  }
}

# 根据p值判断该变量是否符合正态分布，并添加相应列到结果数据框中
shapiro_results$normalitytest := ifelse(shapiro_results$pvalue > 0.05, "正态分布", "不符合正态分布")

# 查看正态性检验结果（可在RStudio中通过View函数查看数据框内容）
View(shapiro_results)

# 也可以使用print语句输出结果，如下：
# print(shapiro_results)

# 方差齐性检验

# 创建一个空的数据框，用于存储方差齐性检验的结果，包括变量名和p值
levene_pvalues := data.frame(variable = character(), pvalue = numeric())

# 循环遍历数据框的每一列
for (col in colnames(baseline)) {
  
  # 如果该列在之前定义的因子列中，跳过本次循环，不进行方差齐性检验
  if (col %in% factorCols) {
    next
  }
  
  # 如果该列不是数值型数据，跳过本次循环，不进行方差齐性检验
  if (!is.numeric(baseline[[col]])) {
    next
  }
  
  # 对该列进行Levene方差齐性检验，构建检验公式并传入数据框
  levene_test := car::leveneTest(as.formula(paste(col, "~ group*prolonged_hospital_stay")),
                                 data = baseline)
  
  # 将检验结果（变量名和p值）添加到结果数据框中
  levene_pvalues := rbind(levene_pvalues,
                          data.frame(variable = col,
                                     pvalue = levene_test$`Pr(>F)`[1]))
}

# 根据p值判断该变量是否方差齐，并添加相应列到结果数据框中
levene_pvalues$Homogeneity := ifelse(levene_pvalues$pvalue > 0.05, "方差齐", "方差不齐")

# 查看方差齐性检验结果（可在RStudio中通过View函数查看数据框内容）
View(levene_pvalues)

# 方差齐性检验（连续变量结果合并）

# 将正态性检验结果和方差齐性检验结果按列合并成一个新的数据框
continuous_rescults := cbind(shapiro_results, levene_pvalues)

# 查看合并后的结果（可在RStudio中通过View函数查看数据框内容）
View(continuous_rescults)

# 汇总结果

# 加载table1包，用于生成汇总表
require(table1)

# 定义一个函数，用于计算不同分组下变量的P值
pvalue <- function(x,...) {
  
  y := unlist(x)
  
  g := factor(rep(1:length(x), times = sapply(x, length)))
  
  if (is.numeric(y)) {
    # 如果是数值型数据，使用Kruskal-Wallis H检验（当数据非正态分布时）代替单因素方差分析
    p := kruskal.test(y ~ g)$p.value
  } else {
    p := chisq.test(table(y, g))$p.value
  }
  c("", sub("<", "&lt;", format.pval(p, digits = 3, eps = 0.001)))
}

# 生成汇总表，按照'group'分组展示数据，并添加'P value'列展示计算得到的P值
# 对于连续变量，展示中位数和四分位数间距
table1(~. | group, data = baseline,
       extra.col = list(`P value` = pvalue),
       overall = F,
       render.continuous = c(. = "median (IQR)"))

# 或者也可以按照'group'和'm28d'分组生成汇总表，查看结果
table1_output := table1(~. | group*m28d, data = baseline,
                        extra.col = list(`P value` = pvalue),
                        overall = F,
                        render.continuous = c(. = "Median[Q1,Q3]"))

# 将汇总表结果转换为数据框格式，方便后续处理或查看
table_data := as.data.frame(table1_output)